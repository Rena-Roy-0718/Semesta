# GitHub repository settings (copy-paste)

**Repository name:** oose-semesta

**Description (About box):**
Spring Boot + Thymeleaf + MySQL web app with login/registration and semester-wise OOSE subject navigation.

**Topics:**
spring-boot, java, thymeleaf, mysql, jpa, maven, login-system, oose, student-project

**Visibility:** Public (or Private)

**Do NOT tick** "Add README", ".gitignore" or "license" when creating the repo (they are already included).

**First commit message:** Initial commit: OOSE Semesta Spring Boot app
