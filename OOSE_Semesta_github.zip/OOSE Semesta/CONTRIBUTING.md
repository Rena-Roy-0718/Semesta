# Contributing

1. Fork the repository and create a branch: `git checkout -b feature/your-feature`
2. Make your changes and run the tests: `cd sampleapp && ./mvnw test`
3. Commit with a clear message: `git commit -m "Add: short description"`
4. Push the branch and open a Pull Request.

Please do not commit passwords, `target/` folders or IDE files.
