package com.example.sampleapp.controller;

import com.example.sampleapp.model.User;
import com.example.sampleapp.repository.UserRepository;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class UserController {

    @Autowired
    private UserRepository userRepository;

    // Show login page
    @GetMapping("/")
    public String showLoginForm(Model model) {
        model.addAttribute("user", new User());
        return "login";
    }

    // Handle login form submission
    @PostMapping("/login")
    public String loginUser(@ModelAttribute User user, HttpSession session, RedirectAttributes redirectAttributes) {
        return userRepository.findFirstByUsername(user.getUsername())
                .filter(existingUser -> existingUser.getPassword().equals(user.getPassword()))
                .map(existingUser -> {
                    session.setAttribute("username", existingUser.getUsername());
                    redirectAttributes.addFlashAttribute("message", "Login successful");
                    return "redirect:/home";
                })
                .orElseGet(() -> {
                    redirectAttributes.addFlashAttribute("message", "Invalid username or password");
                    return "redirect:/";
                });
    }

    // Show home page (add this handler)
    @GetMapping("/home")
    public String showHomePage(HttpSession session, Model model) {
        if (!isLoggedIn(session)) {
            return "redirect:/";  // Redirect to login if no session
        }
        model.addAttribute("username", session.getAttribute("username"));
        return "home";
    }

    @GetMapping("/semester/{sem}")
    public String showSemesterPage(@PathVariable String sem, HttpSession session, Model model) {
        if (!isLoggedIn(session)) {
            return "redirect:/";
        }

        model.addAttribute("username", session.getAttribute("username"));
        model.addAttribute("sem", sem);
        return "semester";
    }

    @GetMapping("/subject/oose")
    public String showOosePage(HttpSession session, Model model) {
        if (!isLoggedIn(session)) {
            return "redirect:/";
        }

        model.addAttribute("username", session.getAttribute("username"));
        return "oose";
    }

    @GetMapping("/unit1")
    public String showUnitOnePage(HttpSession session, Model model) {
        if (!isLoggedIn(session)) {
            return "redirect:/";
        }

        model.addAttribute("username", session.getAttribute("username"));
        return "unit1";
    }

    // Optional: register new users
    @PostMapping("/register")
    public String registerUser(@ModelAttribute User user, RedirectAttributes redirectAttributes) {
        if (userRepository.existsByUsername(user.getUsername())) {
            redirectAttributes.addFlashAttribute("message", "Username already exists");
            return "redirect:/";
        }

        userRepository.save(user);
        redirectAttributes.addFlashAttribute("message", "User Registered Successfully!");
        return "redirect:/";
    }

    private boolean isLoggedIn(HttpSession session) {
        return session.getAttribute("username") != null;
    }
}
