package com.example.sampleapp;

import com.example.sampleapp.model.User;
import com.example.sampleapp.controller.UserController;
import com.example.sampleapp.repository.UserRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.ui.ConcurrentModel;
import org.springframework.ui.Model;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.web.servlet.mvc.support.RedirectAttributesModelMap;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
class SampleappApplicationTests {

	@Autowired
	private UserController userController;

	@Autowired
	private UserRepository userRepository;

	@Test
	void contextLoads() {
	}

	@Test
	void loginWithCorrectCredentialsRedirectsToHome() throws Exception {
		userRepository.deleteAll();
		userRepository.save(new User("alice", "secret"));

		MockHttpSession session = new MockHttpSession();
		RedirectAttributesModelMap redirectAttributes = new RedirectAttributesModelMap();
		User loginAttempt = new User("alice", "secret");
		String redirect = userController.loginUser(loginAttempt, session, redirectAttributes);

		assertThat(redirect).isEqualTo("redirect:/home");
		assertThat(session.getAttribute("username")).isEqualTo("alice");
		assertThat(redirectAttributes.getFlashAttributes().get("message"))
				.isEqualTo("Login successful");

		Model model = new ConcurrentModel();
		String view = userController.showHomePage(session, model);
		assertThat(view).isEqualTo("home");
		assertThat(model.getAttribute("username")).isEqualTo("alice");
	}

	@Test
	void registerRejectsDuplicateUsername() throws Exception {
		userRepository.deleteAll();
		userRepository.save(new User("bob", "pw1"));

		RedirectAttributesModelMap redirectAttributes = new RedirectAttributesModelMap();
		String redirect = userController.registerUser(new User("bob", "pw2"), redirectAttributes);

		assertThat(redirect).isEqualTo("redirect:/");
		assertThat(redirectAttributes.getFlashAttributes().get("message"))
				.isEqualTo("Username already exists");
		assertThat(userRepository.count()).isEqualTo(1);
	}

	@Test
	void semesterFourPageLoadsForLoggedInUser() {
		MockHttpSession session = new MockHttpSession();
		session.setAttribute("username", "alice");
		Model model = new ConcurrentModel();

		String view = userController.showSemesterPage("4", session, model);

		assertThat(view).isEqualTo("semester");
		assertThat(model.getAttribute("sem")).isEqualTo("4");
		assertThat(model.getAttribute("username")).isEqualTo("alice");
	}

	@Test
	void ooseAndUnitPagesRequireLoginAndLoadWhenSessionExists() {
		MockHttpSession noSession = new MockHttpSession();
		Model firstModel = new ConcurrentModel();

		assertThat(userController.showOosePage(noSession, firstModel)).isEqualTo("redirect:/");
		assertThat(userController.showUnitOnePage(noSession, new ConcurrentModel())).isEqualTo("redirect:/");

		MockHttpSession loggedInSession = new MockHttpSession();
		loggedInSession.setAttribute("username", "alice");

		assertThat(userController.showOosePage(loggedInSession, new ConcurrentModel())).isEqualTo("oose");
		assertThat(userController.showUnitOnePage(loggedInSession, new ConcurrentModel())).isEqualTo("unit1");
	}

}
